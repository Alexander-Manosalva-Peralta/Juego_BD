from db import get_db_connection
from datetime import datetime


# Registrar un usuario en la base de datos
def register_user(nombre_usuario, email, contraseña):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO Usuarios (nombre_usuario, email, contraseña, fecha_registro) 
            VALUES (%s, %s, %s, %s)
        """, (nombre_usuario, email, contraseña, datetime.now()))
        conn.commit()
    except Exception as e:
        print(f"Error al registrar usuario: {e}")
    finally:
        cursor.close()
        conn.close()


# Verificar si un usuario ya existe en la base de datos
def check_user_exists(email):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT * FROM Usuarios WHERE email = %s", (email,))
        user = cursor.fetchone()
        return user  # Retorna el usuario si existe
    except Exception as e:
        print(f"Error al verificar si el usuario existe: {e}")
    finally:
        cursor.close()
        conn.close()
    return None


# Registrar una sesión en la base de datos
def register_session(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO Sesiones (id_usuario, fecha_inicio, fecha_fin) 
            VALUES (%s, %s, %s)
        """, (user_id, datetime.now(), 'Activo'))
        conn.commit()
    except Exception as e:
        print(f"Error al registrar sesión: {e}")
    finally:
        cursor.close()
        conn.close()


# Registrar un voto en la base de datos
def register_vote(user_id, direction, id_juego):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Asegurarse de que la dirección sea válida
        if direction not in ['ARRIBA', 'ABAJO', 'DERECHA', 'IZQUIERDA']:
            raise ValueError("Dirección no válida.")

        cursor.execute("""
            INSERT INTO Votos (id_usuario, direccion, id_juego, fecha_voto) 
            VALUES (%s, %s, %s, %s)
        """, (user_id, direction, id_juego, datetime.now()))
        conn.commit()
    except Exception as e:
        print(f"Error al registrar voto: {e}")
    finally:
        cursor.close()
        conn.close()


# Registrar un movimiento en la base de datos
def register_movement(id_juego, direccion, cantidad_votos):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Asegurarse de que la dirección sea válida
        if direccion not in ['ARRIBA', 'ABAJO', 'DERECHA', 'IZQUIERDA']:
            raise ValueError("Dirección no válida.")

        cursor.execute("""
            INSERT INTO Movimientos (id_juego, direccion, cantidad_votos, fecha_movimiento) 
            VALUES (%s, %s, %s, %s)
        """, (id_juego, direccion, cantidad_votos, datetime.now()))
        conn.commit()
    except Exception as e:
        print(f"Error al registrar movimiento: {e}")
    finally:
        cursor.close()
        conn.close()


# Registrar un juego en la base de datos
def register_game():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO Juegos (fecha_juego, estado_juego) 
            VALUES (%s, %s)
        """, (datetime.now(), 'EN PROCESO'))
        conn.commit()
        return cursor.lastrowid  # Retornar el id del juego recién creado
    except Exception as e:
        print(f"Error al registrar juego: {e}")
    finally:
        cursor.close()
        conn.close()


# Registrar la participación en el historial de juegos
def register_historial(user_id, id_juego):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO Historial_Juegos (id_usuario, id_juego, fecha_participacion) 
            VALUES (%s, %s, %s)
        """, (user_id, id_juego, datetime.now()))
        conn.commit()
    except Exception as e:
        print(f"Error al registrar historial: {e}")
    finally:
        cursor.close()
        conn.close()
