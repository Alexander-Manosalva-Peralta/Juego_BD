import pygame
import sys
from game import SnakeGame
from user import register_user, check_user_exists, register_session

# Dimensiones de la pantalla
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

# Colores personalizados
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (100, 149, 237)
LIGHT_BLUE = (173, 216, 230)
GREY = (169, 169, 169)
LIGHT_GREY = (211, 211, 211)
NEON_GREEN = (57, 255, 20)
NEON_BLUE = (0, 191, 255)

# Inicializar Pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Snake Game')
clock = pygame.time.Clock()

# Fuente personalizada
font = pygame.font.Font(pygame.font.get_default_font(), 36)
futuristic_font = pygame.font.Font("futuristic_font.ttf", 48)  # Asegúrate de tener esta fuente

# Función para dibujar texto en pantalla
def draw_text(surface, text, pos, font_size=36, color=WHITE):
    font = pygame.font.Font(None, font_size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=pos)
    surface.blit(text_surface, text_rect)

# Función para crear un fondo animado
def draw_background():
    # Un fondo de gradiente simple
    for y in range(SCREEN_HEIGHT):
        color = (0, int(255 * (y / SCREEN_HEIGHT)), int(255 * (1 - y / SCREEN_HEIGHT)))
        pygame.draw.line(screen, color, (0, y), (SCREEN_WIDTH, y))

def iniciar_nuevo_juego():
    id_juego = registrar_juego()  # Esta función debe registrar un nuevo juego y retornar el id
    return id_juego

# Menú principal
def main_menu():
    while True:
        draw_background()  # Dibuja el fondo animado
        draw_text(screen, "Snake Game", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 4), font_size=60, color=NEON_GREEN)
        draw_text(screen, "1. Registrar usuario", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 40), font_size=36, color=WHITE)
        draw_text(screen, "2. Jugar", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), font_size=36, color=WHITE)
        draw_text(screen, "3. Ver juego en vivo", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 40), font_size=36, color=WHITE)
        draw_text(screen, "4. Salir", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 80), font_size=36, color=WHITE)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    register_user_interface()
                elif event.key == pygame.K_2:
                    user_data = get_user_data()
                    if user_data:
                        game = SnakeGame(user_data)
                        game.show_game()
                elif event.key == pygame.K_3:
                    live_game_interface()
                elif event.key == pygame.K_4:
                    pygame.quit()
                    sys.exit()

# Función para el registro de usuario
def register_user_interface():
    username = ""
    email = ""
    password = ""
    input_active = [True, False, False]  # Control de campos
    current_field = 0  # Para el cambio de campo

    input_boxes = [pygame.Rect(250, 150, 300, 50), pygame.Rect(250, 220, 300, 50), pygame.Rect(250, 290, 300, 50)]

    while True:
        draw_background()  # Dibuja el fondo animado
        draw_text(screen, "Registro de Usuario", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 6), font_size=60, color=NEON_GREEN)

        # Dibujar cajas de texto con colores resaltados
        for i, box in enumerate(input_boxes):
            if input_active[i]:
                pygame.draw.rect(screen, NEON_BLUE, box, 2)  # Borde azul si está activo
            else:
                pygame.draw.rect(screen, LIGHT_GREY, box, 2)  # Borde gris claro si no está activo

        # Mostrar texto ingresado
        draw_text(screen, username, (input_boxes[0].x + 150, input_boxes[0].y + 25), 24, color=WHITE)
        draw_text(screen, email, (input_boxes[1].x + 150, input_boxes[1].y + 25), 24, color=WHITE)
        draw_text(screen, '*' * len(password), (input_boxes[2].x + 150, input_boxes[2].y + 25), 24, color=WHITE)

        # Dibujar botón de "Registrar"
        button_rect = pygame.Rect(325, 370, 150, 50)
        pygame.draw.rect(screen, LIGHT_BLUE, button_rect)
        draw_text(screen, "Registrar", (button_rect.x + button_rect.w // 2, button_rect.y + button_rect.h // 2), font_size=30, color=BLACK)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Verificar si se hace clic en las cajas de texto o en el botón
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if button_rect.collidepoint(event.pos):
                    if username and email and password:
                        if not check_user_exists(email):
                            register_user(username, email, password)
                            register_session(email)
                            confirm_registration_interface()
                            return  # Vuelve al menú principal después de registrar
                        else:
                            print("El usuario ya existe.")
                else:
                    for i, box in enumerate(input_boxes):
                        if box.collidepoint(event.pos):
                            input_active = [False] * 3
                            input_active[i] = True
                            current_field = i

            # Manejo del teclado para ingreso de texto
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    if current_field == 0:
                        username = username[:-1]
                    elif current_field == 1:
                        email = email[:-1]
                    elif current_field == 2:
                        password = password[:-1]
                elif event.key == pygame.K_RETURN:
                    if username and email and password:
                        if not check_user_exists(email):
                            register_user(username, email, password)
                            register_session(email)
                            confirm_registration_interface()
                            return  # Vuelve al menú principal después de registrar
                        else:
                            print("El usuario ya existe.")
                else:
                    if current_field == 0 and len(username) < 20:
                        username += event.unicode
                    elif current_field == 1 and len(email) < 30:
                        email += event.unicode
                    elif current_field == 2 and len(password) < 20:
                        password += event.unicode

# Función para confirmar registro
def confirm_registration_interface():
    while True:
        draw_background()  # Dibuja el fondo animado
        draw_text(screen, "Usuario registrado exitosamente!", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 4), font_size=36, color=NEON_GREEN)
        draw_text(screen, "¿Quieres jugar o ver el juego en vivo?", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 40), font_size=30, color=WHITE)
        draw_text(screen, "1. Jugar", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), font_size=30, color=WHITE)
        draw_text(screen, "2. Ver juego en vivo", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 40), font_size=30, color=WHITE)
        draw_text(screen, "Esc para volver al menú principal", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 80), font_size=30, color=WHITE)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    user_data = get_user_data()
                    if user_data:
                        game = SnakeGame(user_data)
                        game.show_game()
                    return
                elif event.key == pygame.K_2:
                    live_game_interface()
                    return
                elif event.key == pygame.K_ESCAPE:
                    return

# Función para obtener datos del usuario
def get_user_data():
    email = ""
    while True:
        draw_background()  # Dibuja el fondo animado
        draw_text(screen, "Ingrese su email para continuar", (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 4), font_size=36, color=NEON_GREEN)
        draw_text(screen, email, (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), font_size=30, color=WHITE)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    email = email[:-1]
                elif event.key == pygame.K_RETURN:
                    if check_user_exists(email):
                        return email
                    else:
                        print("El usuario no existe.")
                else:
                    email += event.unicode

# Aquí puedes agregar la función live_game_interface() para el juego en vivo

if __name__ == "__main__":
    main_menu()
    pygame.quit()
