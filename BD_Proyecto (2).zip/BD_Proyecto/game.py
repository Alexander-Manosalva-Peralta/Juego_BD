import pygame
import random
from collections import deque
from user import register_vote, register_movement, register_game, register_historial

# Inicializar Pygame y cargar la fuente
pygame.init()

# Dimensiones de la pantalla
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

# Colores personalizados
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)  # Color de la serpiente
RED = (255, 0, 0)  # Color de la manzana
DARK_BLUE = (0, 0, 50)
LIGHT_BLUE = (173, 216, 230)

# Tamaño de bloques y velocidad
SNAKE_BLOCK = 20
SNAKE_SPEED = 15
MOVE_DISTANCE = SNAKE_BLOCK

# Cargar imágenes
snake_image = pygame.image.load("snake_image.png")  # Asegúrate de tener una imagen de la serpiente
food_image = pygame.image.load("food_image.png")    # Asegúrate de tener una imagen de la manzana

class SnakeGame:
    def __init__(self, user_data):
        self.snake = deque([(100, 50), (80, 50), (60, 50)])
        self.direction = 'RIGHT'
        self.score = 0
        self.food_position = self.place_food()
        self.game_over = False
        self.user_data = user_data
        self.votes = {"UP": 0, "DOWN": 0, "LEFT": 0, "RIGHT": 0}
        self.player_votes = {}
        self.vote_time = pygame.time.get_ticks()
        self.game_duration = 20  # Tiempo de votación en segundos
        self.moving = False
        self.id_juego = register_game()  # Registrar el juego en la base de datos
        self.already_voted_message = ""

    def place_food(self):
        x = random.randint(0, (SCREEN_WIDTH - SNAKE_BLOCK) // SNAKE_BLOCK) * SNAKE_BLOCK
        y = random.randint(0, (SCREEN_HEIGHT - SNAKE_BLOCK) // SNAKE_BLOCK) * SNAKE_BLOCK
        return (x, y)

    def update(self):
        if not self.game_over:
            self.check_voting()
            if self.moving:
                self.move()
                self.check_collisions()
                self.check_food()

    def check_voting(self):
        current_time = pygame.time.get_ticks()
        if current_time - self.vote_time > self.game_duration * 1000:
            if any(self.votes.values()):
                direction = max(self.votes, key=self.votes.get)
                register_movement(self.id_juego, direction, self.votes[direction])
                self.direction = direction
                self.moving = True

            self.votes = {"UP": 0, "DOWN": 0, "LEFT": 0, "RIGHT": 0}
            self.player_votes = {}
            self.vote_time = current_time
            self.already_voted_message = ""

    def vote(self, direction):
        user_id = self.user_data[0]
        if user_id not in self.player_votes:
            register_vote(user_id, direction, self.id_juego)
            self.votes[direction] += 1
            self.player_votes[user_id] = direction
        else:
            self.already_voted_message = f"Ya votaste: {self.player_votes[user_id]}"

    def move(self):
        head_x, head_y = self.snake[0]

        if self.direction == 'UP':
            head_y -= MOVE_DISTANCE
        elif self.direction == 'DOWN':
            head_y += MOVE_DISTANCE
        elif self.direction == 'LEFT':
            head_x -= MOVE_DISTANCE
        elif self.direction == 'RIGHT':
            head_x += MOVE_DISTANCE

        self.snake.appendleft((head_x, head_y))
        self.snake.pop()
        self.moving = False

    def check_collisions(self):
        head_x, head_y = self.snake[0]
        if (head_x < 0 or head_x >= SCREEN_WIDTH or
            head_y < 0 or head_y >= SCREEN_HEIGHT or
            (head_x, head_y) in list(self.snake)[1:]):
            self.game_over = True

    def check_food(self):
        if self.snake[0] == self.food_position:
            self.snake.append(self.snake[-1])  # Añadir bloque a la serpiente
            self.food_position = self.place_food()  # Colocar una nueva manzana
            self.score += 1

    def show_game(self):
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Snake Game")
        clock = pygame.time.Clock()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP and self.direction != 'DOWN':
                        self.vote('UP')
                    elif event.key == pygame.K_DOWN and self.direction != 'UP':
                        self.vote('DOWN')
                    elif event.key == pygame.K_LEFT and self.direction != 'RIGHT':
                        self.vote('LEFT')
                    elif event.key == pygame.K_RIGHT and self.direction != 'LEFT':
                        self.vote('RIGHT')

            self.update()

            # Cambiar el fondo para un efecto futurista
            screen.fill(DARK_BLUE)

            # Dibujar la serpiente con imagen
            for block in self.snake:
                screen.blit(snake_image, (block[0], block[1]))  # Usar imagen para la serpiente

            # Dibujar la manzana con imagen
            screen.blit(food_image, (self.food_position[0], self.food_position[1]))  # Usar imagen para la manzana

            self.draw_score(screen, self.score)

            # Mostrar temporizador
            remaining_time = max(0, (self.vote_time + self.game_duration * 1000 - pygame.time.get_ticks()) // 1000)
            self.draw_text(screen, f"Tiempo restante: {remaining_time}s", (SCREEN_WIDTH // 2, 20), font_size=24)

            # Mostrar votos
            self.draw_text(screen, f"Votos: ARRIBA {self.votes['UP']} | ABAJO {self.votes['DOWN']} | IZQUIERDA {self.votes['LEFT']} | DERECHA {self.votes['RIGHT']}", (SCREEN_WIDTH // 2, 50), font_size=24)

            # Mostrar mensaje de "ya votaste" si es necesario
            if self.already_voted_message:
                self.draw_text(screen, self.already_voted_message, (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50), font_size=24)

            pygame.display.flip()
            clock.tick(SNAKE_SPEED)

            if self.game_over:
                break

    # Función para dibujar el puntaje
    def draw_score(self, surface, score):
        font = pygame.font.Font(None, 36)
        score_surface = font.render(f"Score: {score}", True, WHITE)
        surface.blit(score_surface, (10, 10))

    # Función para dibujar texto
    def draw_text(self, surface, text, pos, font_size=36):
        font = pygame.font.Font(None, font_size)
        text_surface = font.render(text, True, WHITE)
        text_rect = text_surface.get_rect(center=pos)
        surface.blit(text_surface, text_rect)

# Cargar las imágenes de la serpiente y la manzana
snake_image = pygame.transform.scale(pygame.image.load("snake_image.png"), (SNAKE_BLOCK, SNAKE_BLOCK))
food_image = pygame.transform.scale(pygame.image.load("food_image.png"), (SNAKE_BLOCK, SNAKE_BLOCK))
